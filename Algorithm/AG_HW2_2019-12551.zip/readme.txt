# Compile

javac *.java

# Run with adjacency matrix
java Main -m < example.txt

# Run with adjacency list
java Main -l < example.txt

# Run with adjacency array
java Main -a < example.txt